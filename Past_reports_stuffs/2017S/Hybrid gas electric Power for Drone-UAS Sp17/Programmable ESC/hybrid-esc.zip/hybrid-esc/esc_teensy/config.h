////////////////////////////////////////////////////////////////////////////////
// Pins
////////////////////////////////////////////////////////////////////////////////
#define INHA 6
#define INLA 5
#define INHB 4
#define INLB 0
#define INHC 3
#define INLC 2

#define HALL1 14
#define HALL2 15
#define HALL3 16

#define THROTTLE A7

#define DRV_EN_GATE 7
#define DRV_CS 10
#define DRV_MOSI 11
#define DRV_MISO 12
#define DRV_CLK 13

#define DRV_FAULT 9
