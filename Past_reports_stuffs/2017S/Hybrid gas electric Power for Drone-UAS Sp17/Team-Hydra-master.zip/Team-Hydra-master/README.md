# Team-Hydra
For the hybrid gas-electric engine team of Duke's Ocean Engineering team for the 2017 Shell X-Prize.
